# EduManager - Système de Gestion Scolaire

EduManager est une application web complète de gestion scolaire développée avec Django. Elle permet de gérer les classes, les élèves et les professeurs d'un établissement scolaire.

## Fonctionnalités

### Gestion des Classes
- ✅ Créer, lire, modifier et supprimer des classes
- ✅ Voir le nombre d'élèves par classe
- ✅ Filtrer et rechercher des classes
- ✅ Voir la liste des élèves d'une classe

### Gestion des Élèves
- ✅ Créer, lire, modifier et supprimer des élèves
- ✅ Informations complètes (personnelles, scolaires, contact, parents)
- ✅ Upload de photo
- ✅ Filtrer par classe et rechercher
- ✅ Pagination
- ✅ Statut actif/inactif

### Gestion des Professeurs
- ✅ Créer, lire, modifier et supprimer des professeurs
- ✅ Informations professionnelles (matière, salaire, date d'embauche)
- ✅ Upload de photo
- ✅ Filtrer par matière et rechercher
- ✅ Pagination
- ✅ Statut actif/inactif

### Tableau de Bord
- ✅ Statistiques globales
- ✅ Actions rapides
- ✅ Données récentes
- ✅ Répartition des élèves par classe

## Technologies Utilisées

- **Backend**: Django 6.0
- **Frontend**: Bootstrap 5, Bootstrap Icons
- **Formulaires**: Django Crispy Forms avec Bootstrap 5
- **Base de données**: SQLite (par défaut)
- **Polices**: Google Fonts (Poppins)

## Installation

### Prérequis
- Python 3.12+
- pip

### Étapes d'installation

1. **Cloner ou télécharger le projet**
   ```bash
   cd gestion_scolaire
   ```

2. **Installer les dépendances**
   ```bash
   pip install django django-crispy-forms crispy-bootstrap5 Pillow
   ```

3. **Effectuer les migrations**
   ```bash
   python manage.py migrate
   ```

4. **Créer un superutilisateur (optionnel)**
   ```bash
   python manage.py createsuperuser
   ```

5. **Charger les données de démo (optionnel)**
   ```bash
   python manage.py seed_data
   ```

6. **Lancer le serveur de développement**
   ```bash
   python manage.py runserver
   ```

7. **Accéder à l'application**
   - Ouvrez votre navigateur et allez à : http://127.0.0.1:8000/
   - Interface d'administration : http://127.0.0.1:8000/admin/

## Structure du Projet

```
gestion_scolaire/
├── config/                 # Configuration du projet Django
│   ├── settings.py        # Paramètres du projet
│   ├── urls.py            # URLs principales
│   └── wsgi.py            # Configuration WSGI
├── gestion/                # Application principale
│   ├── models.py          # Modèles (Classe, Eleve, Professeur)
│   ├── views.py           # Vues (CRUD)
│   ├── forms.py           # Formulaires
│   ├── urls.py            # URLs de l'application
│   ├── admin.py           # Configuration de l'admin
│   ├── templates/         # Templates HTML
│   │   └── gestion/
│   │       ├── base.html
│   │       ├── tableau_de_bord.html
│   │       ├── classe_list.html
│   │       ├── classe_detail.html
│   │       ├── classe_form.html
│   │       ├── classe_confirm_delete.html
│   │       ├── eleve_list.html
│   │       ├── eleve_detail.html
│   │       ├── eleve_form.html
│   │       ├── eleve_confirm_delete.html
│   │       ├── professeur_list.html
│   │       ├── professeur_detail.html
│   │       ├── professeur_form.html
│   │       └── professeur_confirm_delete.html
│   └── management/
│       └── commands/
│           └── seed_data.py  # Commande pour créer des données de démo
├── static/                 # Fichiers statiques
│   ├── css/
│   │   └── style.css      # Styles personnalisés
│   └── js/
│       └── main.js        # JavaScript personnalisé
├── media/                  # Fichiers uploadés (photos)
├── db.sqlite3             # Base de données SQLite
└── manage.py              # Script de gestion Django
```

## Utilisation

### Navigation

- **Tableau de bord**: Page d'accueil avec statistiques et actions rapides
- **Classes**: Gestion complète des classes
- **Élèves**: Gestion complète des élèves avec photos
- **Professeurs**: Gestion complète des professeurs avec photos

### Opérations CRUD

Pour chaque entité (Classe, Élève, Professeur), vous pouvez :

1. **Créer**: Cliquez sur le bouton "Nouveau/Nouvelle" et remplissez le formulaire
2. **Lire**: Cliquez sur "Voir" pour afficher les détails
3. **Modifier**: Cliquez sur l'icône de crayon pour éditer
4. **Supprimer**: Cliquez sur l'icône de corbeille pour supprimer (confirmation requise)

### Recherche et Filtrage

- Utilisez la barre de recherche pour trouver par nom, email, etc.
- Filtrez les élèves par classe
- Filtrez les professeurs par matière

## Personnalisation

### Modifier les styles

Les styles personnalisés sont dans `static/css/style.css`. Vous pouvez modifier :
- Les couleurs des cartes statistiques
- Les polices
- Les animations
- Les espacements

### Modifier les modèles

Pour ajouter des champs aux modèles :

1. Modifiez `gestion/models.py`
2. Créez une migration : `python manage.py makemigrations`
3. Appliquez la migration : `python manage.py migrate`

## Sécurité

- Protection CSRF activée sur tous les formulaires
- Validation des données côté serveur
- Messages de confirmation avant suppression

## Développement Futur

Idées d'améliorations possibles :
- Système d'authentification utilisateur
- Gestion des notes et bulletins
- Emploi du temps
- Présences
- Messagerie interne
- Export des données (PDF, Excel)
- API REST

## Licence

Ce projet est libre d'utilisation pour des fins éducatives.

## Auteur

Développé avec ❤️ pour faciliter la gestion scolaire.
