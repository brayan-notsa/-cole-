#!/bin/bash

echo "=========================================="
echo "  EduManager - Gestion Scolaire"
echo "=========================================="
echo ""

# Vérifier si Python est installé
if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 n'est pas installé"
    exit 1
fi

echo "✅ Python 3 trouvé"

# Vérifier si les dépendances sont installées
echo "📦 Vérification des dépendances..."
python3 -c "import django" 2>/dev/null
if [ $? -ne 0 ]; then
    echo "📥 Installation des dépendances..."
    pip3 install -r requirements.txt
fi

echo "✅ Dépendances OK"

# Vérifier si la base de données existe
if [ ! -f "db.sqlite3" ]; then
    echo "🗄️  Création de la base de données..."
    python3 manage.py migrate
    echo "🌱 Chargement des données de démo..."
    python3 manage.py seed_data
fi

echo ""
echo "=========================================="
echo "  🚀 Lancement du serveur..."
echo "=========================================="
echo ""
echo "  📱 Application: http://127.0.0.1:8000/"
echo "  🔧 Admin:      http://127.0.0.1:8000/admin/"
echo ""
echo "  Identifiants admin:"
echo "    - Utilisateur: admin"
echo "    - Mot de passe: admin123"
echo ""
echo "  Appuyez sur Ctrl+C pour arrêter"
echo ""
echo "=========================================="
echo ""

python3 manage.py runserver
