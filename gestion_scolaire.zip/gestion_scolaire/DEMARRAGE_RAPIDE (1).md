# Démarrage Rapide - EduManager

## Lancer l'application

```bash
# Se placer dans le dossier du projet
cd gestion_scolaire

# Lancer le serveur
python manage.py runserver
```

## Accès

- **Application**: http://127.0.0.1:8000/
- **Administration**: http://127.0.0.1:8000/admin/

## Identifiants

### Superutilisateur
- **Nom d'utilisateur**: `admin`
- **Mot de passe**: `admin123`

## Données de Démo

L'application est pré-remplie avec :
- **14 classes** (6ème à Terminale)
- **12 professeurs** (différentes matières)
- **150 élèves** répartis dans les classes

## Fonctionnalités Principales

### Tableau de Bord
- Statistiques globales
- Actions rapides
- Données récentes

### Classes
- Liste des classes avec nombre d'élèves
- Création, modification, suppression
- Détail avec liste des élèves

### Élèves
- Liste avec photos et filtres
- Informations complètes (personnelles, scolaires, parents)
- CRUD complet

### Professeurs
- Liste avec photos et filtres
- Informations professionnelles
- CRUD complet

## Commandes Utiles

```bash
# Créer un superutilisateur
python manage.py createsuperuser

# Charger des données de démo
python manage.py seed_data

# Réinitialiser la base de données
python manage.py flush

# Sauvegarder les données
python manage.py dumpdata > backup.json

# Restaurer les données
python manage.py loaddata backup.json
```

## Personnalisation

Modifier les styles dans `static/css/style.css`
Modifier les modèles dans `gestion/models.py`
