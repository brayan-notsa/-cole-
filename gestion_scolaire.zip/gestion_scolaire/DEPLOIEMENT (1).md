# Déploiement d'EduManager

Ce document explique comment déployer EduManager en ligne.

## Option 1: Déploiement sur Render (Recommandé - Gratuit)

### Étape 1: Créer un compte Render
1. Allez sur https://render.com
2. Créez un compte gratuit avec GitHub

### Étape 2: Créer un nouveau Web Service
1. Cliquez sur "New" → "Web Service"
2. Choisissez "Deploy from GitHub repository" ou uploadz le code directement

### Étape 3: Configuration
- **Name**: `edumanager` (ou le nom de votre choix)
- **Runtime**: Python 3
- **Build Command**: `./build.sh`
- **Start Command**: `gunicorn config.wsgi:application --bind 0.0.0.0:$PORT --workers 4`

### Étape 4: Variables d'environnement
Ajoutez ces variables dans l'onglet "Environment":
- `SECRET_KEY`: Une clé secrète aléatoire (générez-en une sur https://djecrety.ir/)
- `DEBUG`: `False`
- `ALLOWED_HOSTS`: `*` (ou votre nom de domaine Render)

### Étape 5: Disk persistant (pour la base de données)
1. Allez dans l'onglet "Disks"
2. Cliquez sur "Add Disk"
- **Name**: `data`
- **Mount Path**: `/app/data`
- **Size**: 1 GB (suffisant pour commencer)

### Étape 6: Déployer
Cliquez sur "Create Web Service" et attendez le déploiement.

---

## Option 2: Déploiement avec Docker

### Prérequis
- Docker installé sur votre machine

### Construction de l'image
```bash
cd gestion_scolaire
docker build -t edumanager .
```

### Exécution du conteneur
```bash
docker run -p 8000:8000 -v $(pwd)/data:/app/data edumanager
```

L'application sera accessible sur http://localhost:8000

---

## Option 3: Déploiement local avec Gunicorn

### Installation des dépendances
```bash
pip install -r requirements.txt
```

### Collecte des fichiers statiques
```bash
python manage.py collectstatic --noinput
```

### Lancement avec Gunicorn
```bash
gunicorn config.wsgi:application --bind 0.0.0.0:8000 --workers 4
```

---

## Identifiants par défaut

Après le déploiement, vous pouvez vous connecter à l'interface d'administration:
- **URL**: `https://votre-app.render.com/admin/`
- **Utilisateur**: `admin`
- **Mot de passe**: `admin123`

---

## Personnalisation

### Changer le mot de passe admin
```bash
python manage.py changepassword admin
```

### Créer un nouveau superutilisateur
```bash
python manage.py createsuperuser
```

---

## Support

Pour toute question ou problème, consultez la documentation Django:
https://docs.djangoproject.com/fr/4.2/howto/deployment/
