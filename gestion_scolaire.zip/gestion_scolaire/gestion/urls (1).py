from django.urls import path
from . import views

urlpatterns = [
    # Tableau de bord
    path('', views.tableau_de_bord, name='tableau_de_bord'),
    
    # URLs pour les Classes
    path('classes/', views.ClasseListView.as_view(), name='classe_list'),
    path('classes/<int:pk>/', views.ClasseDetailView.as_view(), name='classe_detail'),
    path('classes/creer/', views.ClasseCreateView.as_view(), name='classe_create'),
    path('classes/<int:pk>/modifier/', views.ClasseUpdateView.as_view(), name='classe_update'),
    path('classes/<int:pk>/supprimer/', views.ClasseDeleteView.as_view(), name='classe_delete'),
    
    # URLs pour les Élèves
    path('eleves/', views.EleveListView.as_view(), name='eleve_list'),
    path('eleves/<int:pk>/', views.EleveDetailView.as_view(), name='eleve_detail'),
    path('eleves/creer/', views.EleveCreateView.as_view(), name='eleve_create'),
    path('eleves/<int:pk>/modifier/', views.EleveUpdateView.as_view(), name='eleve_update'),
    path('eleves/<int:pk>/supprimer/', views.EleveDeleteView.as_view(), name='eleve_delete'),
    
    # URLs pour les Professeurs
    path('professeurs/', views.ProfesseurListView.as_view(), name='professeur_list'),
    path('professeurs/<int:pk>/', views.ProfesseurDetailView.as_view(), name='professeur_detail'),
    path('professeurs/creer/', views.ProfesseurCreateView.as_view(), name='professeur_create'),
    path('professeurs/<int:pk>/modifier/', views.ProfesseurUpdateView.as_view(), name='professeur_update'),
    path('professeurs/<int:pk>/supprimer/', views.ProfesseurDeleteView.as_view(), name='professeur_delete'),
]
