from django.db import models
from django.urls import reverse
from django.core.validators import EmailValidator


class Classe(models.Model):
    """Modèle représentant une classe scolaire"""
    nom = models.CharField(max_length=50, verbose_name="Nom de la classe")
    niveau = models.CharField(max_length=50, verbose_name="Niveau")
    annee_scolaire = models.CharField(max_length=20, verbose_name="Année scolaire")
    description = models.TextField(blank=True, verbose_name="Description")
    date_creation = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Classe"
        verbose_name_plural = "Classes"
        ordering = ['nom']

    def __str__(self):
        return f"{self.nom} - {self.niveau}"

    def get_absolute_url(self):
        return reverse('classe_detail', kwargs={'pk': self.pk})

    def nombre_eleves(self):
        return self.eleves.count()


class Professeur(models.Model):
    """Modèle représentant un professeur"""
    GENRE_CHOICES = [
        ('M', 'Monsieur'),
        ('F', 'Madame'),
        ('A', 'Autre'),
    ]

    nom = models.CharField(max_length=100, verbose_name="Nom")
    prenom = models.CharField(max_length=100, verbose_name="Prénom")
    genre = models.CharField(max_length=1, choices=GENRE_CHOICES, verbose_name="Genre")
    date_naissance = models.DateField(verbose_name="Date de naissance", null=True, blank=True)
    email = models.EmailField(validators=[EmailValidator()], verbose_name="Email", unique=True)
    telephone = models.CharField(max_length=20, verbose_name="Téléphone", blank=True)
    adresse = models.TextField(verbose_name="Adresse", blank=True)
    matiere = models.CharField(max_length=100, verbose_name="Matière principale")
    date_embauche = models.DateField(verbose_name="Date d'embauche", null=True, blank=True)
    salaire = models.DecimalField(max_digits=10, decimal_places=2, verbose_name="Salaire", null=True, blank=True)
    photo = models.ImageField(upload_to='professeurs/', verbose_name="Photo", blank=True, null=True)
    actif = models.BooleanField(default=True, verbose_name="Actif")
    date_creation = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Professeur"
        verbose_name_plural = "Professeurs"
        ordering = ['nom', 'prenom']

    def __str__(self):
        return f"{self.prenom} {self.nom}"

    def get_absolute_url(self):
        return reverse('professeur_detail', kwargs={'pk': self.pk})

    def nom_complet(self):
        return f"{self.prenom} {self.nom}"


class Eleve(models.Model):
    """Modèle représentant un élève"""
    GENRE_CHOICES = [
        ('M', 'Garçon'),
        ('F', 'Fille'),
        ('A', 'Autre'),
    ]

    nom = models.CharField(max_length=100, verbose_name="Nom")
    prenom = models.CharField(max_length=100, verbose_name="Prénom")
    genre = models.CharField(max_length=1, choices=GENRE_CHOICES, verbose_name="Genre")
    date_naissance = models.DateField(verbose_name="Date de naissance")
    lieu_naissance = models.CharField(max_length=100, verbose_name="Lieu de naissance", blank=True)
    email = models.EmailField(validators=[EmailValidator()], verbose_name="Email", blank=True)
    telephone = models.CharField(max_length=20, verbose_name="Téléphone", blank=True)
    adresse = models.TextField(verbose_name="Adresse", blank=True)
    classe = models.ForeignKey(Classe, on_delete=models.SET_NULL, null=True, blank=True, 
                               related_name='eleves', verbose_name="Classe")
    numero_matricule = models.CharField(max_length=50, verbose_name="Numéro de matricule", unique=True)
    date_inscription = models.DateField(verbose_name="Date d'inscription", auto_now_add=True)
    photo = models.ImageField(upload_to='eleves/', verbose_name="Photo", blank=True, null=True)
    nom_parent = models.CharField(max_length=100, verbose_name="Nom du parent/tuteur")
    telephone_parent = models.CharField(max_length=20, verbose_name="Téléphone du parent")
    email_parent = models.EmailField(verbose_name="Email du parent", blank=True)
    actif = models.BooleanField(default=True, verbose_name="Actif")
    date_creation = models.DateTimeField(auto_now_add=True)
    date_modification = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Élève"
        verbose_name_plural = "Élèves"
        ordering = ['nom', 'prenom']

    def __str__(self):
        return f"{self.prenom} {self.nom}"

    def get_absolute_url(self):
        return reverse('eleve_detail', kwargs={'pk': self.pk})

    def nom_complet(self):
        return f"{self.prenom} {self.nom}"

    def age(self):
        from datetime import date
        if self.date_naissance:
            today = date.today()
            return today.year - self.date_naissance.year - ((today.month, today.day) < (self.date_naissance.month, self.date_naissance.day))
        return None
