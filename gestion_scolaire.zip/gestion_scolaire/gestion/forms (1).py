from django import forms
from crispy_forms.helper import FormHelper
from crispy_forms.layout import Layout, Submit, Row, Column, Field
from .models import Classe, Eleve, Professeur


class ClasseForm(forms.ModelForm):
    class Meta:
        model = Classe
        fields = ['nom', 'niveau', 'annee_scolaire', 'description']
        widgets = {
            'description': forms.Textarea(attrs={'rows': 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.layout = Layout(
            Row(
                Column('nom', css_class='form-group col-md-6'),
                Column('niveau', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            'annee_scolaire',
            'description',
            Submit('submit', 'Enregistrer', css_class='btn btn-primary')
        )


class EleveForm(forms.ModelForm):
    class Meta:
        model = Eleve
        fields = ['nom', 'prenom', 'genre', 'date_naissance', 'lieu_naissance',
                  'email', 'telephone', 'adresse', 'classe', 'numero_matricule',
                  'photo', 'nom_parent', 'telephone_parent', 'email_parent', 'actif']
        widgets = {
            'date_naissance': forms.DateInput(attrs={'type': 'date'}),
            'adresse': forms.Textarea(attrs={'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.enctype = 'multipart/form-data'
        self.helper.layout = Layout(
            Row(
                Column('nom', css_class='form-group col-md-6'),
                Column('prenom', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            Row(
                Column('genre', css_class='form-group col-md-4'),
                Column('date_naissance', css_class='form-group col-md-4'),
                Column('lieu_naissance', css_class='form-group col-md-4'),
                css_class='form-row'
            ),
            Row(
                Column('email', css_class='form-group col-md-6'),
                Column('telephone', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            'adresse',
            Row(
                Column('classe', css_class='form-group col-md-6'),
                Column('numero_matricule', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            'photo',
            Row(
                Column('nom_parent', css_class='form-group col-md-4'),
                Column('telephone_parent', css_class='form-group col-md-4'),
                Column('email_parent', css_class='form-group col-md-4'),
                css_class='form-row'
            ),
            'actif',
            Submit('submit', 'Enregistrer', css_class='btn btn-primary')
        )


class ProfesseurForm(forms.ModelForm):
    class Meta:
        model = Professeur
        fields = ['nom', 'prenom', 'genre', 'date_naissance', 'email', 
                  'telephone', 'adresse', 'matiere', 'date_embauche', 
                  'salaire', 'photo', 'actif']
        widgets = {
            'date_naissance': forms.DateInput(attrs={'type': 'date'}),
            'date_embauche': forms.DateInput(attrs={'type': 'date'}),
            'adresse': forms.Textarea(attrs={'rows': 2}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.helper = FormHelper()
        self.helper.form_method = 'post'
        self.helper.enctype = 'multipart/form-data'
        self.helper.layout = Layout(
            Row(
                Column('nom', css_class='form-group col-md-6'),
                Column('prenom', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            Row(
                Column('genre', css_class='form-group col-md-4'),
                Column('date_naissance', css_class='form-group col-md-4'),
                Column('matiere', css_class='form-group col-md-4'),
                css_class='form-row'
            ),
            Row(
                Column('email', css_class='form-group col-md-6'),
                Column('telephone', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            'adresse',
            Row(
                Column('date_embauche', css_class='form-group col-md-6'),
                Column('salaire', css_class='form-group col-md-6'),
                css_class='form-row'
            ),
            'photo',
            'actif',
            Submit('submit', 'Enregistrer', css_class='btn btn-primary')
        )
