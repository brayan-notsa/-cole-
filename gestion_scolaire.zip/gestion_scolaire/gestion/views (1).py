from django.shortcuts import render, get_object_or_404, redirect
from django.views.generic import ListView, DetailView, CreateView, UpdateView, DeleteView
from django.urls import reverse_lazy
from django.contrib import messages
from django.db.models import Q, Count, Avg
from .models import Classe, Eleve, Professeur
from .forms import ClasseForm, EleveForm, ProfesseurForm


def tableau_de_bord(request):
    """Vue du tableau de bord avec statistiques"""
    context = {
        'total_classes': Classe.objects.count(),
        'total_eleves': Eleve.objects.count(),
        'total_professeurs': Professeur.objects.count(),
        'eleves_actifs': Eleve.objects.filter(actif=True).count(),
        'professeurs_actifs': Professeur.objects.filter(actif=True).count(),
        'classes_recentes': Classe.objects.order_by('-date_creation')[:5],
        'eleves_recents': Eleve.objects.order_by('-date_creation')[:5],
        'professeurs_recents': Professeur.objects.order_by('-date_creation')[:5],
        'classes': Classe.objects.annotate(nb_eleves=Count('eleves')),
    }
    return render(request, 'gestion/tableau_de_bord.html', context)


# ==================== VUES POUR LES CLASSES ====================

class ClasseListView(ListView):
    model = Classe
    template_name = 'gestion/classe_list.html'
    context_object_name = 'classes'
    paginate_by = 10

    def get_queryset(self):
        queryset = super().get_queryset()
        search = self.request.GET.get('search')
        if search:
            queryset = queryset.filter(
                Q(nom__icontains=search) | 
                Q(niveau__icontains=search) |
                Q(annee_scolaire__icontains=search)
            )
        return queryset.annotate(nb_eleves=Count('eleves'))

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search'] = self.request.GET.get('search', '')
        return context


class ClasseDetailView(DetailView):
    model = Classe
    template_name = 'gestion/classe_detail.html'
    context_object_name = 'classe'

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['eleves'] = self.object.eleves.all()
        return context


class ClasseCreateView(CreateView):
    model = Classe
    form_class = ClasseForm
    template_name = 'gestion/classe_form.html'
    success_url = reverse_lazy('classe_list')

    def form_valid(self, form):
        messages.success(self.request, 'La classe a été créée avec succès.')
        return super().form_valid(form)


class ClasseUpdateView(UpdateView):
    model = Classe
    form_class = ClasseForm
    template_name = 'gestion/classe_form.html'
    success_url = reverse_lazy('classe_list')

    def form_valid(self, form):
        messages.success(self.request, 'La classe a été modifiée avec succès.')
        return super().form_valid(form)


class ClasseDeleteView(DeleteView):
    model = Classe
    template_name = 'gestion/classe_confirm_delete.html'
    success_url = reverse_lazy('classe_list')

    def delete(self, request, *args, **kwargs):
        messages.success(request, 'La classe a été supprimée avec succès.')
        return super().delete(request, *args, **kwargs)


# ==================== VUES POUR LES ÉLÈVES ====================

class EleveListView(ListView):
    model = Eleve
    template_name = 'gestion/eleve_list.html'
    context_object_name = 'eleves'
    paginate_by = 12

    def get_queryset(self):
        queryset = super().get_queryset()
        search = self.request.GET.get('search')
        classe_id = self.request.GET.get('classe')
        
        if search:
            queryset = queryset.filter(
                Q(nom__icontains=search) | 
                Q(prenom__icontains=search) |
                Q(numero_matricule__icontains=search) |
                Q(email__icontains=search)
            )
        
        if classe_id:
            queryset = queryset.filter(classe_id=classe_id)
            
        return queryset.select_related('classe')

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search'] = self.request.GET.get('search', '')
        context['classe_filter'] = self.request.GET.get('classe', '')
        context['classes'] = Classe.objects.all()
        return context


class EleveDetailView(DetailView):
    model = Eleve
    template_name = 'gestion/eleve_detail.html'
    context_object_name = 'eleve'


class EleveCreateView(CreateView):
    model = Eleve
    form_class = EleveForm
    template_name = 'gestion/eleve_form.html'
    success_url = reverse_lazy('eleve_list')

    def form_valid(self, form):
        messages.success(self.request, 'L\'élève a été créé avec succès.')
        return super().form_valid(form)


class EleveUpdateView(UpdateView):
    model = Eleve
    form_class = EleveForm
    template_name = 'gestion/eleve_form.html'
    success_url = reverse_lazy('eleve_list')

    def form_valid(self, form):
        messages.success(self.request, 'L\'élève a été modifié avec succès.')
        return super().form_valid(form)


class EleveDeleteView(DeleteView):
    model = Eleve
    template_name = 'gestion/eleve_confirm_delete.html'
    success_url = reverse_lazy('eleve_list')

    def delete(self, request, *args, **kwargs):
        messages.success(request, 'L\'élève a été supprimé avec succès.')
        return super().delete(request, *args, **kwargs)


# ==================== VUES POUR LES PROFESSEURS ====================

class ProfesseurListView(ListView):
    model = Professeur
    template_name = 'gestion/professeur_list.html'
    context_object_name = 'professeurs'
    paginate_by = 12

    def get_queryset(self):
        queryset = super().get_queryset()
        search = self.request.GET.get('search')
        matiere = self.request.GET.get('matiere')
        
        if search:
            queryset = queryset.filter(
                Q(nom__icontains=search) | 
                Q(prenom__icontains=search) |
                Q(email__icontains=search) |
                Q(telephone__icontains=search)
            )
        
        if matiere:
            queryset = queryset.filter(matiere__icontains=matiere)
            
        return queryset

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context['search'] = self.request.GET.get('search', '')
        context['matiere_filter'] = self.request.GET.get('matiere', '')
        # Récupérer les matières uniques pour le filtre
        context['matieres'] = Professeur.objects.values_list('matiere', flat=True).distinct()
        return context


class ProfesseurDetailView(DetailView):
    model = Professeur
    template_name = 'gestion/professeur_detail.html'
    context_object_name = 'professeur'


class ProfesseurCreateView(CreateView):
    model = Professeur
    form_class = ProfesseurForm
    template_name = 'gestion/professeur_form.html'
    success_url = reverse_lazy('professeur_list')

    def form_valid(self, form):
        messages.success(self.request, 'Le professeur a été créé avec succès.')
        return super().form_valid(form)


class ProfesseurUpdateView(UpdateView):
    model = Professeur
    form_class = ProfesseurForm
    template_name = 'gestion/professeur_form.html'
    success_url = reverse_lazy('professeur_list')

    def form_valid(self, form):
        messages.success(self.request, 'Le professeur a été modifié avec succès.')
        return super().form_valid(form)


class ProfesseurDeleteView(DeleteView):
    model = Professeur
    template_name = 'gestion/professeur_confirm_delete.html'
    success_url = reverse_lazy('professeur_list')

    def delete(self, request, *args, **kwargs):
        messages.success(request, 'Le professeur a été supprimé avec succès.')
        return super().delete(request, *args, **kwargs)
