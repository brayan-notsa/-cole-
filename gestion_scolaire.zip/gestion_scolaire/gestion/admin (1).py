from django.contrib import admin
from .models import Classe, Eleve, Professeur


@admin.register(Classe)
class ClasseAdmin(admin.ModelAdmin):
    list_display = ['nom', 'niveau', 'annee_scolaire', 'nombre_eleves', 'date_creation']
    list_filter = ['niveau', 'annee_scolaire']
    search_fields = ['nom', 'niveau', 'description']
    ordering = ['nom']
    
    def nombre_eleves(self, obj):
        return obj.nombre_eleves()
    nombre_eleves.short_description = 'Nombre d\'élèves'


@admin.register(Eleve)
class EleveAdmin(admin.ModelAdmin):
    list_display = ['nom_complet', 'numero_matricule', 'classe', 'genre', 'age', 'actif', 'date_inscription']
    list_filter = ['genre', 'actif', 'classe', 'date_inscription']
    search_fields = ['nom', 'prenom', 'numero_matricule', 'email', 'nom_parent']
    ordering = ['nom', 'prenom']
    readonly_fields = ['date_creation', 'date_modification']
    
    fieldsets = (
        ('Informations personnelles', {
            'fields': ('nom', 'prenom', 'genre', 'date_naissance', 'lieu_naissance', 'photo')
        }),
        ('Informations scolaires', {
            'fields': ('numero_matricule', 'classe', 'date_inscription')
        }),
        ('Contact', {
            'fields': ('email', 'telephone', 'adresse')
        }),
        ('Parent/Tuteur', {
            'fields': ('nom_parent', 'telephone_parent', 'email_parent')
        }),
        ('Statut', {
            'fields': ('actif',)
        }),
        ('Métadonnées', {
            'fields': ('date_creation', 'date_modification'),
            'classes': ('collapse',)
        }),
    )


@admin.register(Professeur)
class ProfesseurAdmin(admin.ModelAdmin):
    list_display = ['nom_complet', 'matiere', 'email', 'telephone', 'actif', 'date_embauche']
    list_filter = ['genre', 'actif', 'matiere', 'date_embauche']
    search_fields = ['nom', 'prenom', 'email', 'matiere', 'telephone']
    ordering = ['nom', 'prenom']
    readonly_fields = ['date_creation', 'date_modification']
    
    fieldsets = (
        ('Informations personnelles', {
            'fields': ('nom', 'prenom', 'genre', 'date_naissance', 'photo')
        }),
        ('Informations professionnelles', {
            'fields': ('matiere', 'date_embauche', 'salaire')
        }),
        ('Contact', {
            'fields': ('email', 'telephone', 'adresse')
        }),
        ('Statut', {
            'fields': ('actif',)
        }),
        ('Métadonnées', {
            'fields': ('date_creation', 'date_modification'),
            'classes': ('collapse',)
        }),
    )
