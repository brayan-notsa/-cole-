from django.core.management.base import BaseCommand
from gestion.models import Classe, Eleve, Professeur
from datetime import date, timedelta
import random


class Command(BaseCommand):
    help = 'Crée des données de démo pour l\'application de gestion scolaire'

    def handle(self, *args, **kwargs):
        self.stdout.write('Création des données de démo...')
        
        # Créer les classes
        classes_data = [
            {'nom': '6ème A', 'niveau': '6ème', 'annee_scolaire': '2024-2025'},
            {'nom': '6ème B', 'niveau': '6ème', 'annee_scolaire': '2024-2025'},
            {'nom': '5ème A', 'niveau': '5ème', 'annee_scolaire': '2024-2025'},
            {'nom': '5ème B', 'niveau': '5ème', 'annee_scolaire': '2024-2025'},
            {'nom': '4ème A', 'niveau': '4ème', 'annee_scolaire': '2024-2025'},
            {'nom': '4ème B', 'niveau': '4ème', 'annee_scolaire': '2024-2025'},
            {'nom': '3ème A', 'niveau': '3ème', 'annee_scolaire': '2024-2025'},
            {'nom': '3ème B', 'niveau': '3ème', 'annee_scolaire': '2024-2025'},
            {'nom': 'Seconde A', 'niveau': 'Seconde', 'annee_scolaire': '2024-2025'},
            {'nom': 'Seconde B', 'niveau': 'Seconde', 'annee_scolaire': '2024-2025'},
            {'nom': 'Première A', 'niveau': 'Première', 'annee_scolaire': '2024-2025'},
            {'nom': 'Première B', 'niveau': 'Première', 'annee_scolaire': '2024-2025'},
            {'nom': 'Terminale A', 'niveau': 'Terminale', 'annee_scolaire': '2024-2025'},
            {'nom': 'Terminale B', 'niveau': 'Terminale', 'annee_scolaire': '2024-2025'},
        ]
        
        classes = []
        for data in classes_data:
            classe, created = Classe.objects.get_or_create(
                nom=data['nom'],
                defaults={
                    'niveau': data['niveau'],
                    'annee_scolaire': data['annee_scolaire'],
                    'description': f'Classe de {data["niveau"]} - Année scolaire {data["annee_scolaire"]}'
                }
            )
            classes.append(classe)
            if created:
                self.stdout.write(f'  ✓ Classe créée: {classe.nom}')
        
        # Créer les professeurs
        professeurs_data = [
            {'nom': 'Martin', 'prenom': 'Sophie', 'genre': 'F', 'matiere': 'Mathématiques', 'email': 'sophie.martin@edu.fr'},
            {'nom': 'Bernard', 'prenom': 'Pierre', 'genre': 'M', 'matiere': 'Français', 'email': 'pierre.bernard@edu.fr'},
            {'nom': 'Petit', 'prenom': 'Marie', 'genre': 'F', 'matiere': 'Histoire-Géographie', 'email': 'marie.petit@edu.fr'},
            {'nom': 'Robert', 'prenom': 'Jean', 'genre': 'M', 'matiere': 'Physique-Chimie', 'email': 'jean.robert@edu.fr'},
            {'nom': 'Richard', 'prenom': 'Isabelle', 'genre': 'F', 'matiere': 'SVT', 'email': 'isabelle.richard@edu.fr'},
            {'nom': 'Durand', 'prenom': 'Michel', 'genre': 'M', 'matiere': 'Anglais', 'email': 'michel.durand@edu.fr'},
            {'nom': 'Leroy', 'prenom': 'Catherine', 'genre': 'F', 'matiere': 'Espagnol', 'email': 'catherine.leroy@edu.fr'},
            {'nom': 'Moreau', 'prenom': 'Philippe', 'genre': 'M', 'matiere': 'EPS', 'email': 'philippe.moreau@edu.fr'},
            {'nom': 'Simon', 'prenom': 'Nathalie', 'genre': 'F', 'matiere': 'Arts Plastiques', 'email': 'nathalie.simon@edu.fr'},
            {'nom': 'Laurent', 'prenom': 'Christophe', 'genre': 'M', 'matiere': 'Musique', 'email': 'christophe.laurent@edu.fr'},
            {'nom': 'Lefebvre', 'prenom': 'Sandrine', 'genre': 'F', 'matiere': 'Technologie', 'email': 'sandrine.lefebvre@edu.fr'},
            {'nom': 'Michel', 'prenom': 'François', 'genre': 'M', 'matiere': 'Philosophie', 'email': 'francois.michel@edu.fr'},
        ]
        
        professeurs = []
        for data in professeurs_data:
            prof, created = Professeur.objects.get_or_create(
                email=data['email'],
                defaults={
                    'nom': data['nom'],
                    'prenom': data['prenom'],
                    'genre': data['genre'],
                    'matiere': data['matiere'],
                    'date_naissance': date(random.randint(1960, 1990), random.randint(1, 12), random.randint(1, 28)),
                    'telephone': f'0{random.randint(1, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)}',
                    'date_embauche': date(random.randint(2000, 2020), random.randint(1, 12), random.randint(1, 28)),
                    'salaire': random.randint(2500, 4500),
                    'actif': True
                }
            )
            professeurs.append(prof)
            if created:
                self.stdout.write(f'  ✓ Professeur créé: {prof.nom_complet}')
        
        # Créer les élèves
        prenoms_garcons = ['Lucas', 'Hugo', 'Nathan', 'Enzo', 'Louis', 'Gabriel', 'Léo', 'Raphaël', 'Ethan', 'Mathis',
                          'Tom', 'Noah', 'Jules', 'Arthur', 'Théo', 'Maxime', 'Paul', 'Alexandre', 'Antoine', 'Baptiste',
                          'Clément', 'Maxence', 'Samuel', 'Victor', 'Adam', 'Ryan', 'Evan', 'Kylian', 'Matteo', 'Mael']
        
        prenoms_filles = ['Emma', 'Léa', 'Chloé', 'Manon', 'Inès', 'Jade', 'Camille', 'Sarah', 'Laura', 'Lola',
                         'Anna', 'Julie', 'Marie', 'Lucie', 'Clara', 'Zoé', 'Lina', 'Eva', 'Alice', 'Charlotte',
                         'Amandine', 'Célia', 'Elisa', 'Margaux', 'Maëlys', 'Noémie', 'Océane', 'Pauline', 'Romane', 'Valentine']
        
        noms = ['Dubois', 'Thomas', 'Garcia', 'Rodriguez', 'Martinez', 'Lopez', 'Gonzalez', 'Perez', 'Moreau', 'Simon',
                'Laurent', 'Lefebvre', 'Michel', 'Garcia', 'Roux', 'Bonnet', 'André', 'François', 'Mercier', 'Dupont',
                'Lambert', 'Rousseau', 'Vincent', 'Muller', 'Lefranc', 'Faure', 'André', 'Gauthier', 'Garcia', 'Perrin']
        
        eleves_crees = 0
        for i in range(150):  # Créer 150 élèves
            genre = random.choice(['M', 'F'])
            if genre == 'M':
                prenom = random.choice(prenoms_garcons)
            else:
                prenom = random.choice(prenoms_filles)
            
            nom = random.choice(noms)
            classe = random.choice(classes)
            
            # Générer un numéro de matricule unique
            annee = '24'
            numero = f'{annee}{classe.id:02d}{i+1:04d}'
            
            eleve, created = Eleve.objects.get_or_create(
                numero_matricule=numero,
                defaults={
                    'nom': nom,
                    'prenom': prenom,
                    'genre': genre,
                    'date_naissance': date(random.randint(2005, 2015), random.randint(1, 12), random.randint(1, 28)),
                    'lieu_naissance': random.choice(['Paris', 'Lyon', 'Marseille', 'Bordeaux', 'Toulouse', 'Nantes', 'Strasbourg', 'Lille']),
                    'email': f'{prenom.lower()}.{nom.lower()}@eleve.edu',
                    'telephone': f'06{random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)}',
                    'adresse': f'{random.randint(1, 100)} rue de {random.choice(["Paris", "Lyon", "Marseille", "Bordeaux", "Toulouse"])}',
                    'classe': classe,
                    'nom_parent': f'{random.choice(noms)} {random.choice(prenoms_garcons + prenoms_filles)}',
                    'telephone_parent': f'06{random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)} {random.randint(0, 9)}{random.randint(0, 9)}',
                    'email_parent': f'parent.{nom.lower()}@email.com',
                    'actif': True
                }
            )
            if created:
                eleves_crees += 1
        
        self.stdout.write(f'  ✓ {eleves_crees} élèves créés')
        
        self.stdout.write(self.style.SUCCESS(
            f'\nDonnées de démo créées avec succès !\n'
            f'  - {len(classes)} classes\n'
            f'  - {len(professeurs)} professeurs\n'
            f'  - {eleves_crees} élèves'
        ))
