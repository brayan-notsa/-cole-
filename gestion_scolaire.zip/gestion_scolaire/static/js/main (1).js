// Main JavaScript for EduManager

document.addEventListener('DOMContentLoaded', function() {
    // Auto-hide alerts after 5 seconds
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            const bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        }, 5000);
    });

    // Confirm delete actions
    const deleteButtons = document.querySelectorAll('.btn-delete');
    deleteButtons.forEach(function(button) {
        button.addEventListener('click', function(e) {
            if (!confirm('Êtes-vous sûr de vouloir supprimer cet élément ?')) {
                e.preventDefault();
            }
        });
    });

    // Photo preview for file inputs
    const photoInputs = document.querySelectorAll('input[type="file"]');
    photoInputs.forEach(function(input) {
        input.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    // Look for existing preview image
                    let preview = input.closest('form').querySelector('.photo-preview');
                    if (!preview) {
                        // Create preview container if it doesn't exist
                        preview = document.createElement('img');
                        preview.className = 'photo-preview mb-3 rounded-circle';
                        preview.style.width = '120px';
                        preview.style.height = '120px';
                        preview.style.objectFit = 'cover';
                        input.parentNode.insertBefore(preview, input);
                    }
                    preview.src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    });

    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function(tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    const popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    popoverTriggerList.map(function(popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Search input focus
    const searchInput = document.querySelector('input[name="search"]');
    if (searchInput) {
        searchInput.focus();
    }

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Add loading state to buttons
    const forms = document.querySelectorAll('form');
    forms.forEach(function(form) {
        form.addEventListener('submit', function() {
            const submitButton = form.querySelector('button[type="submit"]');
            if (submitButton) {
                submitButton.disabled = true;
                submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span>Chargement...';
            }
        });
    });

    // Table row click to navigate
    const tableRows = document.querySelectorAll('.table-clickable tbody tr');
    tableRows.forEach(function(row) {
        row.addEventListener('click', function(e) {
            if (!e.target.closest('a') && !e.target.closest('button')) {
                const link = row.querySelector('a');
                if (link) {
                    window.location.href = link.href;
                }
            }
        });
        row.style.cursor = 'pointer';
    });

    // Print functionality
    const printButtons = document.querySelectorAll('.btn-print');
    printButtons.forEach(function(button) {
        button.addEventListener('click', function() {
            window.print();
        });
    });

    // Dynamic class filter for students
    const classeFilter = document.querySelector('select[name="classe"]');
    if (classeFilter) {
        classeFilter.addEventListener('change', function() {
            this.closest('form').submit();
        });
    }

    // Dynamic matiere filter for teachers
    const matiereFilter = document.querySelector('select[name="matiere"]');
    if (matiereFilter) {
        matiereFilter.addEventListener('change', function() {
            this.closest('form').submit();
        });
    }

    // Confirmation for important actions
    const importantActions = document.querySelectorAll('[data-confirm]');
    importantActions.forEach(function(action) {
        action.addEventListener('click', function(e) {
            const message = this.getAttribute('data-confirm');
            if (!confirm(message)) {
                e.preventDefault();
            }
        });
    });

    // Card hover effects
    const cards = document.querySelectorAll('.hover-card');
    cards.forEach(function(card) {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Input validation feedback
    const validatedInputs = document.querySelectorAll('.is-invalid, .is-valid');
    validatedInputs.forEach(function(input) {
        input.addEventListener('input', function() {
            this.classList.remove('is-invalid', 'is-valid');
        });
    });

    // Date input placeholders
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(function(input) {
        if (!input.value) {
            input.placeholder = 'JJ/MM/AAAA';
        }
    });

    console.log('EduManager - Application loaded successfully!');
});

// Utility functions
function formatDate(dateString) {
    const options = { year: 'numeric', month: 'long', day: 'numeric' };
    return new Date(dateString).toLocaleDateString('fr-FR', options);
}

function formatNumber(number) {
    return new Intl.NumberFormat('fr-FR').format(number);
}

function formatCurrency(amount) {
    return new Intl.NumberFormat('fr-FR', {
        style: 'currency',
        currency: 'EUR'
    }).format(amount);
}

// Export functions for use in other scripts
window.EduManager = {
    formatDate: formatDate,
    formatNumber: formatNumber,
    formatCurrency: formatCurrency
};
