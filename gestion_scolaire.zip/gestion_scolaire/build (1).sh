#!/usr/bin/env bash
# Build script for Render

set -o errexit

echo "Installing dependencies..."
pip install -r requirements.txt

echo "Collecting static files..."
python manage.py collectstatic --noinput

echo "Running migrations..."
python manage.py migrate

echo "Creating superuser if not exists..."
python manage.py shell << EOF
from django.contrib.auth import get_user_model
User = get_user_model()
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin', 'admin@edu.fr', 'admin123')
    print('Superuser created: admin / admin123')
else:
    print('Superuser already exists')
EOF

echo "Seeding data if database is empty..."
python manage.py shell << EOF
from gestion.models import Classe
if Classe.objects.count() == 0:
    print('Database is empty, seeding data...')
    import subprocess
    subprocess.run(['python', 'manage.py', 'seed_data'])
else:
    print('Database already has data')
EOF

echo "Build completed!"
